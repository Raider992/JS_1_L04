'use strict';
let config = {
    countRows: 10,
    countCols: 10
};
