'use strict';
let player = {
    x: 0,
    y: 0,

    move(newPoint) {
        this.x = newPoint.x;
        this.y = newPoint.y;
    }
};
